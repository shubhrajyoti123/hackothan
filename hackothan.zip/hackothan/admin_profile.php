<?php
include('header.php');
include('dbConnection.php');
define('page','dashboard');
session_start();
if(isset($_SESSION['is_admin_login']))
{
	$name=$_SESSION['name'];
	$data=explode("_",$name);
	$first=$data[0];
	$o_first=strtoupper($first);
	
	$sql="SELECT * FROM complaint WHERE dept_id='$o_first'";
	$result=$conn->query($sql);

}
else
{
	echo "<script>window.location.href='http://localhost/hackothan/logout.php';</script>";
}
?>

<header class="bg-danger" style="height:50px">
	<div class="container-fluid">
		<div class="row">
		<div class="col-lg-5 font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		<div class="col-lg-4"></div>
		<div class="col-lg-2"><h1 class="font-weight-bold text-white">
			<?php if($_SESSION['name']=='it_admin')
			{ echo 'IT';}
			else if($_SESSION['name']=='hr_admin')
				{ echo 'HR'; } 
			?>
		<i class="fa fa-user-circle"></i></h1></div>
		</div>
	</div>
</header>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-2">
			<nav>
				<ul class="nav nav-pills flex-column nav-stacked">
					<li class="nav-item"><a href="http://localhost/hackothan/admin_profile.php" class="nav-link <?php if(page=="dashboard"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fas fa-address-card"></i> Dashboard</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/admin_profile.php" class="nav-link <?php if(page=="vacancy"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> Complain detailes</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/admin_history.php" class="nav-link <?php if(page=="history"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> History</a></li>
					
				</ul>
			</nav>
	
		
		</div>
		<div class="col-lg-10">
			<a href="http://localhost/hackothan/logout.php" class="btn btn-danger mt-2"><i class="fa fa-power-off"></i>LogOut</a>
			<?php 
			$sql="SELECT * FROM complaint WHERE dept_id='$o_first' AND status='0'";
			$result=$conn->query($sql);
			if($result->rowCount()>0)
			{
				?>
					<table class="table table-bordered table-striped" id="c_table">
						<thead>
							<tr>
								<th>Subject</th>
								<th>Content</th>
								<th>Name</th>
								<th>start date</th>
								<th>end date</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							while($row=$result->fetch(PDO::FETCH_ASSOC))
				{

					?>
					<tr>
						<td><?php echo $row['subject']; ?></td>
						<td><?php echo $row['content']; ?></td>
						<td><?php echo $row['user']; ?></td>
						<td><?php echo $row['start_date']; ?></td>
						<td><?php echo $row['end_date']; ?></td>
						<td><?php echo $row['status']; ?></td>
						<td><button class="btn btn-success" onclick="state(<?php echo $row['id']; ?>)" value=""><i class="fa fa-paper-plane"></i></button><button class="btn btn-warning ml-2" onclick="send(<?php echo $row['id']; ?>)"><i class="fa fa-envelope"></i></button></td>
					</tr>

						</tbody>
						<?php
					}
					?>
					</table>
				
			<?php	
			}
			else
			{
				?>
				<h2>You have no complaint!!!!</h2>
				<?php
			}
			?>

		</div>
		
	</div>
</div>


<div class="modal fade" id="status_update">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-info" style="height:70px;">
					<h1 class="text-white text-sm"><i class="fas fa-user-secret mr-3"></i>Submit to higher authority</h1>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
         			 <span aria-hidden="true">&times;</span>
        		</button>
				</div>
				<div class="modal-body">
					<form action="" method="post" id="form_stats">
						<div class="row">
							<input type="hidden" name="id_d" id="id_d">
							<div class="col-lg-10">
								<div class="form-group">
									<label>Please provide the required solution</label>
									<input type="text" name="cred" id="cred" class="form-control" placeholder="please enter the solution">
								</div>
							</div>
						</div>
					
				</div>
				<div class="modal-footer">
					<button class="btn btn-success" type="submit" onclick="submitAu()">Submit</button>
					<button class="btn btn-danger" type="reset">Reset</button>
				</div>
				</form>
			</div>
		</div>
	</div>
	<?php include('footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#c_table").dataTable();
	})
	function state(id){
		var a=confirm("Are you sure change the status")
		if(a)
		{
			$.ajax({
				url:"http://localhost/hackothan/change_status.php",
				type:"post",
				data:{id:id},
				success:function(result)
				{
					var data=JSON.parse(result);
					if(data.state==true)
					{
						alert(data.mess);
					}
					else
					{
						alert(data.mess);
					}
				},
				error:function(err)
				{
					alert("Something bad has been happened");
				}
			})
		}
		else
		{
			alert("Status remain");
		}
	}
	function send(id){
		$("#id_d").val(id);
		$("#status_update").modal("show");
	}
	function submitAu()
	{
		var dat=$("#cred").val();
		var id=$("#id_d").val();
		$.ajax({
			url:"http://localhost/hackothan/send_high.php",
			type:"post",
			data:{value:dat,id:id},
			success:function(result)
			{
				alert(result);
				var data=JSON.parse(result);
				if(data.state==true)
				{
					alert(data.mess);
				}
				else
				{
					alert(data.mess);
				}

			},
			error:function(err)
			{
				alert("Unable to perform the operation");
			}
		})
	}
</script>