<?php
include('dbConnection.php');
$id=$_POST['id'];
$sql="UPDATE complaint SET status=2 WHERE id = '$id'";
$affected_row=$conn->exec($sql);
if($affected_row>0)
{
	$msg['state']=true;
	$msg['mess']="Update successfully";
	echo json_encode($msg);
}
else
{
	$msg['state']=false;
	$msg['mess']="Update failed";
	echo json_encode($msg);
}

?>