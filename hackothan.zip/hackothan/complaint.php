<?php
include('dbConnection.php');
define('page','complaint');
session_start();


if(isset($_SESSION['is_login']))
{
	if(isset($_REQUEST['c_submit']))
	{
		$subject=$_POST['subject'];
		$content=$_POST['content'];
		$start_date=$_POST['start_date'];
		$end_date=$_POST['end_date'];
		
		 $name=$_SESSION['name'];
		$fetch="SELECT * FROM user_tb WHERE user_email='$name'";
		$result=$conn->query($fetch);
		$data = $result->fetch(PDO::FETCH_ASSOC);
		//echo $data['department_id'];
		$user=$data['user_name'];
		$d=$_POST['d_detail'];

		$authority=$data['eid'];
		//$d=$data['department_id'];
		// $f=$_FILES['fil'];
		// move_uploaded_file($f['tmp_name'],"pdf/".$f['name']);
		 $filename="http://localhost/hackothan/pdf/"."image.pdf";
		$sql="INSERT INTO complaint(subject,content,files,user,authority,start_date,end_date,dept_id,status)VALUES('$subject','$content','$filename','$user','$authority','$start_date','$end_date','$d',0)";
		
		 $affected_row = $conn->exec($sql);
		 if($affected_row)
		 {

		 	$msg="<div class='alert alert-danger' role='alert'>Data successfully applied</div>";
		 }
		 else
		 {
		 	$msg="<div class='alert alert-danger' role='alert'>Failed to applied</div>";
		 }
	}

}
else
{
	echo "<script>window.location.href='http://localhost/hackothan/logout.php';</script>";
}
?>
<?php include('header.php'); ?>
<header class="bg-danger" style="height:50px">
	<div class="container">
		<div class="font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		
	</div>
</header>

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-2">
			<nav>
				<ul class="nav nav-pills flex-column nav-stacked">
					<li class="nav-item"><a href="http://localhost/hackothan/petition_profile.php" class="nav-link <?php if(page=="dashboard"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fas fa-address-card"></i> Dashboard</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/complaint.php" class="nav-link <?php if(page=="complaint"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> Complain</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/petition_history.php" class="nav-link <?php if(page=="history"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> History</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/super_solution.php" class="nav-link <?php if(page=="final"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> final</a></li>
				</ul>
			</nav>
	
		
		</div>
		<div class="col-lg-10">
			<a href="http://localhost/hackothan/logout.php" class="btn btn-danger mt-2"><i class="fa fa-power-off"></i>LogOut</a>
			<form action="" method="post">
				
				<div class="row">
					<div class="col-lg-12">
						<div class='form-group'>
							<label>Subject</label>
							<input type="text" name="subject" id="sub_id" class="form-control" required>
						</div>
					</div>
					<div class="col-lg-12">
						<div class='form-group'>
							<label>Content</label>
							<textarea type="text" name="content" id="con_id" class="form-control" required></textarea>
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label>Starting Date</label>
							<input type="date" name="start_date" id="s_date" class="form-control">
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label>Ending Date</label>
							<input type="date" name="end_date" id="e_date" class="form-control">
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label>You can enter document file also</label><span class="text-danger">(.docx,.pdf) extention</span>
							<input type="file" name="fil" id="file" class="form-control">
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label>Enter the query for the department</span>
							<select name="d_detail">
								<option>--select department</option>
								<option>IT</option>
								<option>ADMIN</option>
								<option>HR</option>
								

							</select>
						</div>
					</div>
					<div class="col-lg-12">
						<button type="submit" name="c_submit" classsubmit="btn btn-success">Submit</button>
						<button type="reset" class='btn btn-warning'>Reset</button>
					</div>
				</div>
			</form>
		</div>
		
	</div>
</div>
<div class="row">
	<?php if(isset($msg)){ echo $msg;} ?>
	</div>

<?php include('footer.php'); ?>