/*
SQLyog Community v11.42 (32 bit)
MySQL - 10.1.38-MariaDB : Database -grievance_management
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`grievance_management` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `grievance_management`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `eid` int(255) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`eid`,`user_name`,`password`) values (1,'it_admin','itpassword'),(2,'hr_admin','hrpassword');

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `files` varchar(255) DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  `authority` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `dept_id` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`id`,`subject`,`content`,`files`,`user`,`authority`,`start_date`,`end_date`,`dept_id`,`status`) values (1,'work from home due to corona virus','wwork from home due to corona virus','http://localhost/hackothan/pdf/image.jpg','0','','2020-08-29','2020-08-30','1','2'),(2,'work from home due to corona virus','wwork from home due to corona virus','http://localhost/hackothan/pdf/image.jpg','0','','2020-08-29','2020-08-30','1','2'),(3,'work from home due to corona virus','asdfghjakslkbkas','http://localhost/hackothan/pdf/image.jpg','0','1','2020-08-24','2020-08-31','1','2'),(4,'For leave ','database','http://localhost/hackothan/pdf/image.jpg','linkan pradhan','1','2020-08-29','2020-08-30','0','2'),(5,'system ','not working','http://localhost/hackothan/pdf/image.jpg','linkan pradhan','fef','2020-08-20','2020-08-30','IT','0'),(6,'system ','not working','http://localhost/hackothan/pdf/image.jpg','linkan pradhan','1','2020-08-20','2020-08-30','IT','1'),(7,'mouse not working','mouse function is bad ','http://localhost/hackothan/pdf/image.jpg','linkan pradhan','wecloemmee','2020-08-29','2020-08-30','HR','1'),(8,'For leave ','fever','http://localhost/hackothan/pdf/image.pdf','linkan pradhan','1','2020-09-01','2020-09-02','HR','0');

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `dept_id` int(100) NOT NULL AUTO_INCREMENT,
  `details` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `department` */

/*Table structure for table `super_admin` */

DROP TABLE IF EXISTS `super_admin`;

CREATE TABLE `super_admin` (
  `sid` int(255) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `super_admin` */

insert  into `super_admin`(`sid`,`user_name`,`password`) values (1,'super_admin','superpassword');

/*Table structure for table `user_tb` */

DROP TABLE IF EXISTS `user_tb`;

CREATE TABLE `user_tb` (
  `u_id` int(255) NOT NULL AUTO_INCREMENT,
  `eid` int(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `department_id` int(255) DEFAULT NULL,
  PRIMARY KEY (`u_id`,`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `user_tb` */

insert  into `user_tb`(`u_id`,`eid`,`user_name`,`user_email`,`department_id`) values (1,1,'linkan pradhan','linkan@gmail.com',1),(2,2,'','',0),(3,3,'gourishankar tripathy','nihal@gmail.com',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
