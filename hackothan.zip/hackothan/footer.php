<script type="text/javascript" src="http://localhost/hackothan/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="http://localhost/hackothan/assets/js/popper.min.js"></script>
<script type="text/javascript" src="http://localhost/hackothan/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://localhost/hackothan/assets/js/all.min.js"></script>
<script type="text/javascript" src="http://localhost/hackothan/assets/js/jquery.dataTables.min.js"></script>

</body>
</html>
