<!DOCTYPE html>
<html>
<head>
	<title>User</title>
	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<meta http-equiv="X-UA-Compatible" content="ie=edge">
  	<link rel="stylesheet" type="text/css" href="http://localhost/hackothan/assets/css/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="http://localhost/hackothan/assets/css/all.min.css">
  	<link rel="stylesheet" type="text/css" href="http://localhost/hackothan/assets/css/custom.css">
  	<link rel="stylesheet" type="text/css" href="http://localhost/hackothan/assets/css/jquery.dataTables.min.css">
</head>
<body style="font-family: calibri;">

	