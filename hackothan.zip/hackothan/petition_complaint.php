<?php include('header.php'); ?>

<div class="bgimg">
		<nav class="navbar navbar-expand-md  navbar-dark" style="background-color: rgba(0,0,0,0.3);">
			<div class="container">
				<a href="#" class="navbar-brand text-white font-weight-bold"><i class="fa fa-home"></i>CMS</a>
				<button class="navbar-toggler" type="button"  data-toggle="collapse" data-target="#collapseNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<ul class="navbar-nav ml-auto">
						
						<li class="nav-item"><a href="http://localhost/hackothan/petition_login.php" class="nav-link text-white"><i class="fa fa-user"></i> Petition</a></li>
						<li class="nav-item"><a href="http://localhost/hackothan/admin.php" class="nav-link text-white"><i class="fa fa-user-circle"></i> Admin</a></li>
						<li class="nav-item"><a href="http://localhost/hackothan/super_admin.php" class="nav-link text-white"><i class="fa fa-user-circle"></i> SuperAdmin</a></li>
					</ul>
			</div>
		</nav>
		<div class="container text-center headerset text-white">
			
			
		</div>
	</div>
	
<?php include('footer.php'); ?>