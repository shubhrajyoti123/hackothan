<?php 

$dsn = "mysql:host=localhost; dbname=hashing";
 $db_user = "root";
 $db_password = "";
 
 
 try {
  $conn = new PDO($dsn, $db_user, $db_password);

  
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
 }
 catch(PDOException $e) {
  echo "Connection Failed " . $e->getMessage();
 }
if(isset($_REQUEST['psubmit']))
{
 $username=$_POST['c_username'];
 $password=$_POST['c_password'];

 $sql="SELECT * FROM entry WHERE name='$username' AND pass='$password'";
 $result = $conn->query($sql);
 if($result->rowCount() > 0) {
 session_start();
 $_SESSION['name']=$username;
 echo "<script> window.location.href='http://localhost/hackothan/petition_complaint.php'</script>";
  
 }
} else {
 echo "<script> window.location.href='http://localhost/hackothan/petition_login.php'</script>";
}
}
else
{
	echo "data is not present";
}

?>