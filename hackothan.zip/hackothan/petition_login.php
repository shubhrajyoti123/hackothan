<?php 

include('dbConnection.php');
session_start();
if(isset($_REQUEST['psubmit']))
{
	 $email=$_POST['c_username'];
	 $d_id=$_POST['c_password'];

	 $sql="SELECT * FROM user_tb WHERE user_email='$email' AND department_id='$d_id'";
	 $result = $conn->query($sql);
	 if($result->rowCount() > 0) 
	 {
		 $row = $result->fetch(PDO::FETCH_ASSOC);
		 $_SESSION['is_login']=true;
		 $_SESSION['name']=$email;
		 $_SESSION['user']=$row['user_name'];
		 $_SESSION['authority']=$row['e_id'];
		 $_SESSION['d_id']=$row['department_id'];

		 echo "<script> window.location.href='http://localhost/hackothan/petition_profile.php'</script>";
		  
	 }
	 else
	  {
	 	$msg="<div class='alert alert-danger' role='alert'>Enter valid Email and password</div>";

	}
}


?>
<?php include("header.php"); ?>
<header class="bg-danger" style="height:50px">
	<div class="container">
		<div class="font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		
	</div>
</header>
<div class="container">
	
		<h1 class="mt-5" style="text-align: center;">Log in to Your Account</h1>
		<hr>
		<form action="" method="post" id="company_form">
			
	<div class="row">
		<div class='col-lg-12'>
			<div class='form-group'>
				<input type="text" class="form-control" placeholder="Enter your Email"id="c_username" name="c_username" required>
			</div>
		</div>
	</div>
	<div class="row">
		<div class='col-lg-12'>
			<div class='form-group'>
				<input type="text" class="form-control" placeholder="Enter your Department ID" id="c_password" name="c_password" required>
			</div>
		</div>
	</div>
	<div class="row">
		
		<div class="col-lg-6">
			<button class="btn btn-warning font-weight-bold btn-block shadow-sm" type="reset">RESET</button>
		</div>
		<div class="col-lg-6">
			<button class="btn btn-outline-info font-weight-bold btn-block shadow-sm" type="submit" name="psubmit">LOG IN</button>
		</div>
	</div>

</form>
<hr>
<div class="row">
	<a href="http://localhost/hackothan/petition_complaint.php" class="btn btn-info" style="text-decoration: none;"><i class="fa fa-step-backward"></i>Back to Home</a>
	</div><hr>
	<div class="row">
		<?php if(isset($msg)){echo $msg;} ?>
	</div><hr>
	<h5 class="text-center mt-5">New to SRMS? <a href="http://localhost/hackothan/petition_registration.php" class="text-info" style="text-decoration: none">Sign up now</a></h5>
<hr>
</div>
<?php include("footer.php"); ?>