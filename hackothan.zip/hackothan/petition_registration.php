<?php 
include('dbConnection.php');
include("header.php"); 
if(isset($_REQUEST['p_submit']))
{
	$name=$_POST['user_name'];
	$e_id=$_POST['eid'];
	$d_id=$_POST['department_id'];
	$email=$_POST['user_email'];
	$sql="INSERT INTO user_tb(eid,user_name,user_email,department_id)VALUES('$e_id','$name','$email','$d_id')";
	 $affected_row = $conn->exec($sql);
		 if($affected_row)
		 {
		 	$msg="<div class='alert alert-danger' role='alert'>Registed successfully applied</div>";
		 }
		 else
		 {
		 	$msg="<div class='alert alert-danger' role='alert'>Failed to Register</div>";
		 }
}
?>
<header class="bg-danger" style="height:50px">
	<div class="container">
		<div class="font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		
	</div>
</header>
<div class="container">
	<h2 class="text-center mt-5">Create An Account</h2>
	
	<hr>
	<h5 class="text-center"> Sign up with your email address</h5>
	<form action="" method="post">
	<div class="row">
		<div class="col-lg-12">
			<div class='form-group'>
				<label class="text-info"> Enter Your EID</label>
				<input type="text" name="eid" id="username" class="form-control">
			</div>
		</div>
	</div>
	
	
				
			
	<div class="row">
		<div class="col-lg-12">
			<div class='form-group'>
				<label class="text-info"> Name</label>
				<input type="text" name="user_name" id="username" class="form-control">
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-lg-12">
			<div class='form-group'>
				<label class="text-info"> Enter Your Department ID</label>
				<input type="text" name="department_id" id="d_id" class="form-control">
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-lg-12">
			<div class='form-group'>
				<label class="text-info"> Email   </label> 
				<input type="text" name="user_email" id="email" class="form-control" required>
			</div>
		</div>
	</div>
	

	
	<hr>
	<button class="btn btn-outline-info font-weight-bold btn-block shadow-sm" type="submit" name="p_submit">Register</button>
	<div class="row">
		<div class="col-lg-6">
			<button class="btn btn-danger btn-block font-bold shadow-sm mt-3" type="reset">RESET</button>

		</div>
		<div class="col-lg-6">
			<a href="http://localhost/hackothan/petition_complaint.php" class="btn btn-primary btn-block font-bold shadow-sm mt-3"><i class="fa fa-backward"></i>  Back to Home</a>
		</div>
	</div>
</form>
	<div class="row">
		<?php if(isset($msg)){ echo $msg;}?>
	</div>
</div>

<?php include("footer.php"); ?>
