<?php
include("dbConnection.php");
$value=$_POST["value"];
$id=$_POST["id"];

$sql2="UPDATE complaint SET authority='$value' WHERE id = '$id'";
$affected_row=$conn->exec($sql2);

if($affected_row>0)
{
	
	$ms['state']=true;
	$ms['mess']="Solve the problem";
	echo json_encode($ms);
}
else
{

	$msg['state']=false;
	$msg['mess']="Some problem has been occured during solving";
	echo json_encode($msg);
}

?>