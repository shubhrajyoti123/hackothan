<?php 

include('dbConnection.php');
session_start();
if(isset($_REQUEST['asubmit']))
{
	 $username=$_POST['s_username'];
	 $password=$_POST['s_password'];

	 $sql="SELECT * FROM super_admin WHERE user_name='$username' AND password='$password'";
	 $result = $conn->query($sql);

	 if($result->rowCount() > 0) 
	 {

		 $row = $result->fetch(PDO::FETCH_ASSOC);
		 $_SESSION['is_admin_login']=true;
		
		 $_SESSION['name']=$username
		 		;


		 echo "<script> window.location.href='http://localhost/hackothan/super_admin_profile.php'</script>";exit;
		  
	 }
	 else
	  {
	 	$msg="<div class='alert alert-danger' role='alert'>Enter valid Email and password</div>";

	}
}


?>
<?php include("header.php"); ?>
<header class="bg-danger" style="height:50px">
	<div class="container">
		<div class="font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		
	</div>
</header>
<div class="container">
	
		<h1 class="mt-5" style="text-align: center;">Log in to Your Account</h1>
		<hr>
		<form action="" method="post" id="company_form">
			
	<div class="row">
		<div class='col-lg-12'>
			<div class='form-group'>
				<input type="text" class="form-control" placeholder="Enter username"id="s_username" name="s_username" required>
			</div>
		</div>
	</div>
	<div class="row">
		<div class='col-lg-12'>
			<div class='form-group'>
				<input type="password" class="form-control" placeholder="Enter your password" id="s_password" name="s_password" required>
			</div>
		</div>
	</div>
	<div class="row">
		
		<div class="col-lg-6">
			<button class="btn btn-warning font-weight-bold btn-block shadow-sm" type="reset">RESET</button>
		</div>
		<div class="col-lg-6">
			<button class="btn btn-outline-info font-weight-bold btn-block shadow-sm" type="submit" name="asubmit">LOG IN</button>
		</div>
	</div>

</form>
<hr>
<div class="row">
	<a href="http://localhost/hackothan/petition_complaint.php" class="btn btn-info" style="text-decoration: none;"><i class="fa fa-step-backward"></i>Back to Home</a>
	</div><hr>
	<div class="row">
		<?php if(isset($msg)){echo $msg;} ?>
	</div><hr>
	
<hr>
</div>
<?php include("footer.php"); ?>