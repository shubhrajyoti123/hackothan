<?php

include('dbConnection.php');
define('page','history');
session_start();
if(isset($_SESSION['is_admin_login']))
{
	$email=$_SESSION['name'];
	$fetch="SELECT * FROM user_tb WHERE user_email='$email'";
	$result=$conn->query($fetch);
	$row=$result->fetch(PDO::FETCH_ASSOC);

	
}
else
{
	echo "<script>window.location.href='http://localhost/hackothan/logout.php';</script>";
}
?>
<?php include('header.php'); ?>
<header class="bg-danger" style="height:50px">
	<div class="container-fluid">
		<div class="row">
		<div class="col-lg-5 font-weight-bold text-white">
			<h1 class="text-center">CMS</h1>

		</div>
		<div class="col-lg-4"></div>
		<div class="col-lg-2"><h1 class="font-weight-bold text-white">
			<?php if($_SESSION['name']=='super_admin')
			{ echo 'super';}
			
			?>
		<i class="fa fa-user-circle"></i></h1></div>
		</div>
	</div>
</header>

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-2">
			<nav>
				<ul class="nav nav-pills flex-column nav-stacked">
					<li class="nav-item"><a href="http://localhost/hackothan/super_admin_profile.php" class="nav-link <?php if(page=="dashboard"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fas fa-address-card"></i> Dashboard</a></li>
					
					<li class="nav-item"><a href="http://localhost/hackothan/super_admin_profile.php" class="nav-link <?php if(page=="vacancy"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> Complain detailes</a></li>
					<li class="nav-item"><a href="http://localhost/hackothan/super_history.php" class="nav-link <?php if(page=="history"){echo "active bg-dark";}?> bg-info mt-2 text-white text-center"><i class="fa fa-chair"></i> History</a></li>
					
				</ul>
			</nav>
	
		
		</div>
		<div class="col-lg-10">
			<a href="http://localhost/hackothan/logout.php" class="btn btn-danger mt-2"><i class="fa fa-power-off"></i>LogOut</a>
			<?php
			$user=$row['user_name'];
			$sql="SELECT * FROM complaint WHERE status='2'";
			$result=$conn->query($sql);
			if($result->rowCount()>0)
			{
				?>
					<table class="table table-bordered table-striped" id="c_table">
						<thead>
							<tr>
								<th>Subject</th>
								<th>Content</th>
								<th>Name</th>
								<th>start date</th>
								<th>end date</th>
								<th>Status</th>
							
							</tr>
						</thead>
						<tbody>
							<?php 
							while($row=$result->fetch(PDO::FETCH_ASSOC))
				{

					?>
					<tr>
						<td><?php echo $row['subject']; ?></td>
						<td><?php echo $row['content']; ?></td>
						<td><?php echo $row['user']; ?></td>
						<td><?php echo $row['start_date']; ?></td>
						<td><?php echo $row['end_date']; ?></td>
						<td><?php if($row['status']>1){ echo "Solved";}else{ echo "Processing";}; ?></td>
						
					</tr>

						</tbody>
						<?php
					}
					?>
					</table>
				
			<?php	
			}
			else
			{
				?>
				<h2>there is no complain yet!!!!</h2>
				<?php
			}
			?>

		</div>
		
	</div>
</div>

<?php include('footer.php'); ?>